INSERT INTO tasks (summary, description,status) VALUES ('Spring Boot を学ぶ','TODO アプリを作る','DONE')
INSERT INTO tasks (summary, description,status) VALUES ('Spring Security を学ぶ','ログイン機能を作る','TODO')
