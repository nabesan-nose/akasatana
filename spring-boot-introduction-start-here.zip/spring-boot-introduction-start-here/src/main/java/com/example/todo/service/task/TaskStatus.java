package com.example.todo.service.task;

public enum TaskStatus {

    TODO,
    DOING,
    DONE
}
